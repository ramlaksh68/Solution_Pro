import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upload-resume',
  templateUrl: './upload-resume.component.html',
  styleUrls: ['./upload-resume.component.css']
})
export class UploadResumeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
