import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fortgotpassword',
  templateUrl: './fortgotpassword.component.html',
  styleUrls: ['./fortgotpassword.component.css']
})
export class FortgotpasswordComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
