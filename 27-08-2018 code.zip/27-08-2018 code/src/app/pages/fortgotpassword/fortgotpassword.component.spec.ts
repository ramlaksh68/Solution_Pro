import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FortgotpasswordComponent } from './fortgotpassword.component';

describe('FortgotpasswordComponent', () => {
  let component: FortgotpasswordComponent;
  let fixture: ComponentFixture<FortgotpasswordComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FortgotpasswordComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FortgotpasswordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
