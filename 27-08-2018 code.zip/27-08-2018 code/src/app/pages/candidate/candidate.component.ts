import { Component, OnInit, ViewChild } from '@angular/core';
// import { CalenderapiService, Slot } from '../../services/calenderapi.service';
import { DxSchedulerComponent } from 'devextreme-angular/ui/scheduler';
import { UserDataService } from '../../services/userData.service';
import { SchedulerSearvice } from '../../services';
import data from 'devextreme/data/custom_store';
@Component({
  selector: 'app-candidate',
  templateUrl: './candidate.component.html',
  styleUrls: ['./candidate.component.css']
})

export class CandidateComponent implements OnInit {



  display = 'none';
  public dummyData: any;
  dataSource = [];
  currentUser = localStorage.getItem('username');
  token: any = localStorage.getItem('Token');
  public loginId = localStorage.getItem('username');
  @ViewChild(DxSchedulerComponent) scheduler: DxSchedulerComponent;
  slotbooked: boolean = true;
  viewCal: boolean = false;
  otherblock1
  currentDate: Date = new Date();
  constructor(public schedulerSr: SchedulerSearvice, private userService: UserDataService) {

  }

  ngOnInit() {
    this.openModal();
    // this.ViewAvailSlot(this.loginId)
    this.InterviewSlot();
  }

  InterviewSlot(){
        this.schedulerSr.ViewCanditSlots(this.currentUser).subscribe(data => {
      this.dummyData = data
      for (let i = 0; i < this.dummyData.length; i++) {
        this.dataSource.push({
          name: this.dummyData[i].pName,
          text: 'Slot For ' + this.dummyData[i].pName,
          id: this.dummyData[i].slotId,
          color: (this.dummyData[i].status === "open") ? "#87D37C" : "#EC644B",
          startDate: this.dummyData[i].sTime,
          endDate: this.dummyData[i].eTime
        });
      }
    });

  }

  // Unused method
  ViewAvailSlot(event) {
   
    let id = event;
    this.schedulerSr.ViewCanditSlots(id).subscribe(
      data => {
        console.log(data)
        let arr = [];
        for (let i = 0; i < this.dataSource.length; i++) {
          if (this.dataSource[i].id == id) {
            arr.push({
              id: this.dataSource[i].id,
              text: this.dataSource[i].text,
              startDate: this.dataSource[i].sTime,
              endDate: this.dataSource[i].eTime,
              color: "#1e90ff"
            });
          } else {
            arr.push(this.dataSource[i]);
          }
        }
        this.slotbooked = false;
        this.dataSource = arr;
        this.scheduler.instance.hideAppointmentTooltip();
      }
    );
  }

  onAppointmentDeleted(event) {
    let id = event.appointmentData.id;
    let name = event.appointmentData.name;
    this.schedulerSr.CancelCanditSlot(id, this.currentUser);
    // location.reload();
  }

  onAppointmentDeleting(event) {
    let id = event.appointmentData.id;
    let name = event.appointmentData.name;
    this.schedulerSr.CancelCanditSlot(id, this.currentUser);
    //  location.reload();
  }
  onAppointmentAdded() {

  }

  onAppointmentFormCreated() {

  }

  // startDate:Sat Jul 21 2018 08:00:00 GMT+0530 (India Standard Time)endTime:Sat Jul 21 2018 18:00:00 GMT+0530 (India Standard Time)
  //  startDate:2018/07/14 00:00:00endDate:2018/07/15 00:00:00
  onAppointmentAdding($e) {

    let data = $e.appointmentData;
    let JsData = "startDate:" + data.startDate + "GMT+0530 (India Standard Time) endTime:" + data.endDate + "GMT+0530 (India Standard Time)";

    //  let JsData = "startDate:Sat Jul 21 2018 11:00:00 GMT+0530 (India Standard Time)endTime:Sat Jul 21 2018 12:00:00 GMT+0530 (India Standard Time)"

    this.schedulerSr.createCanditSlot(JsData, this.currentUser).subscribe(data => {});
  
  }


  onAppointmentUpdated($e) {
    let data = $e.appointmentData;
    let startdate = new Date(data.startDate);
    let enddate = new Date(data.endDate);
    // startDate:Sat Jul 21 2018 08:00:00 GMT+0530 (India Standard Time)endTime:Sat Jul 21 2018 18:00:00 GMT+0530 (India Standard Time)
    let JsData = "startDate:" + startdate + "GMT+0530 (India Standard Time) endTime:" + enddate + "GMT+0530 (India Standard Time)";
    console.log(JsData)

    this.schedulerSr.UpdateCanditSlot(JsData, this.currentUser);
    //  location.reload();
  }


  openModal() {
    this.display = 'none';
    this.viewCal = true;
  }
  onCloseHandled() {
    this.display = 'none'; this.viewCal = true;
  }
}


