import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Router } from "@angular/router";
import { UserDataService } from '../../services/userData.service';
import { CalenderapiService } from '../../services/calenderapi.service';
import { HttpHeaders } from '@angular/common/http';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [AuthService]
})
export class LoginComponent implements OnInit {
  
  usermatched: boolean = false;
  registeredUser = [{
    Name: "Shwetha",
    Password: "shwe",
    Role: "Interviewer"
  }, {
    Name: "Suchithra",
    Password: "suchi",
    Role: "Candidate"
  }]

  loginForm: FormGroup;

  error: string;
  constructor(private router: Router,
    public auth: AuthService,
    public calender: CalenderapiService,
    fb: FormBuilder) {
    this.loginForm = fb.group({
      'name': ['', Validators.required],
      'password': ['', Validators.required]
    });
  }

  

  ngOnInit() {
  //  this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
  this.checkLogged();
  }

  checkLogged(){
    let result = localStorage.getItem('role');
          if(result){
            if (result=== "C") {
            this.router.navigate(['dashboard/candidate']);
          } else if (result === "I") {
            this.router.navigate(['/dashboard/interviewer']);
          } else if (result === "H") {
            this.router.navigate(['/dashboard/hr']);
          }
          }else{
            this.router.navigate(['/login']);
          }
  }
  login(data) {
    console.log(data)
    let name = data.name;
    let password = data.password;
    this.auth.SetLoggedIn(name, password)
      .subscribe(result => {
        console.log(result)
        this.calender.token = result.token;
        this.calender.role = result.role;
        let token = 'Bearer ' + result.token
        this.calender.httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': this.calender.token
          })
        };
        if (result) {
          this.error = "";
          localStorage.setItem('username', name)
          localStorage.setItem('Token', this.calender.token)
          localStorage.setItem('role', this.calender.role)
          if (result.role === "C") {
            this.router.navigate(['dashboard/candidate']);
          } else if (result.role === "I") {
            this.router.navigate(['/dashboard/interviewer']);
          } else if (result.role === "H") {
            this.router.navigate(['/dashboard/hr']);
          }
        } else {
          this.error = "Username & Password Incorrect";
        }
      }, (error) => { this.error = "Invalid login id and password" });

  }

}
