import { Component, OnInit, ViewChild } from '@angular/core';
import { SchedulerSearvice } from '../../services';
import { Appointment, Resource, CalenderapiService } from '../../services/calenderapi.service';
import { DxSchedulerComponent } from 'devextreme-angular/ui/scheduler';
import data from 'devextreme/data/custom_store';
import { Router } from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'app-scheduler',
  templateUrl: './scheduler.component.html',
  styleUrls: ['./scheduler.css']
})
export class SchedulerComponent {

  @ViewChild(DxSchedulerComponent) scheduler: DxSchedulerComponent;
  currentDate: Date = new Date();
  // resourcesData: Resource[];
  interviewer = {};
  dataSource = [];
  candidate = {
    "Cname": "",
    "Cemail": "",
    "status": "",
    "Ccomments": ""
  };
  public dataFormat: any;
  currentUser = localStorage.getItem('username');
  token: any = localStorage.getItem('Token');
  public loginId = localStorage.getItem('username');
  public dummyData;
  public feedbac_err = {};
  public error : string;
  constructor(
    public router: Router,
    private location: Location,
    private candidateService: CalenderapiService,
    public schedulerSr: SchedulerSearvice) {

      console.log(this.router)
    this.schedulerSr.ViewInterviewSlots(this.currentUser).subscribe(data => {
      this.dummyData = data;
      console.log(data)
      for (let i = 0; i < this.dummyData.length; i++) {
        this.dataSource.push({
          text: 'Slot For ' + this.currentUser,
          id: this.dummyData[i].sSlotId,
          color: (this.dummyData[i].status === 'open') ? "#1e90ff" : "#cb6bb2",
          startDate: this.dummyData[i].sTime,
          endDate: this.dummyData[i].eTime
        });

      }
    })

  }

  FetchAllSlot($e) {

    // for (let i = 0; i < dataFormat.length; i++) {
    //   let startDate = dataFormat[i].startTime.split(" ")[0];
    //   let startTime = dataFormat[i].startTime.split(" ")[1];
    //   let endDate = dataFormat[i].endTime.split(" ")[0];
    //   let endTime = dataFormat[i].endTime.split(" ")[1];
    //   this.dataSource.push({
    //     text: 'Slot For ' + this.currentUser.loginId + '@',
    //     id: dataFormat[i].id,
    //     color: (dataFormat[i].status === 'S') ? "#1e90ff" : "#cb6bb2",
    //     startDate: new Date(startDate.split("/")[2], startDate.split("/")[1] - 1, startDate.split("/")[0], startTime.split(":")[0], startTime.split(":")[1]),
    //     endDate: new Date(endDate.split("/")[2], endDate.split("/")[1] - 1, endDate.split("/")[0], endTime.split(":")[0], endTime.split(":")[1]),
    //   });
    // }
  }
  onAppointmentFormCreated(e) {
    let form = e.form;
    form.itemOption("text", { visible: false });
    form.itemOption("description", { visible: false });
  }
  onAppointmentAdding(appointmentInfo) {
    //After Added the data Resource for any handling we can do the customization

    let slot = appointmentInfo.appointmentData;
    let data = appointmentInfo.appointmentData;
    let startdate = new Date(data.startDate);
    let enddate = new Date(data.endDate);

    let JsData = "startDate:" + String(startdate) + "endTime:" + String(enddate);
    let Slots = { "sTime": JsData }
    this.schedulerSr.createInterviewSlot(Slots, this.loginId);
    // location.reload()    
  }
  onAppointmentAdded(appointmentInfo) {

  }
  onAppointmentUpdated(appointmentInfo) {
    //After updated the data Resource for any handling we can do the customization
  }
  onAppointmentDeleting(appointmentInfo) {
    // this.candidateService.deleteInterviewSlot(appointmentInfo.appointmentData.id).subscribe(data => {
    // });
  }
  onAppointmentDeleted($e) {
    //After deleted the data Resource for any handling we can do the customization

    this.schedulerSr.CancelInterviewSlot(this.loginId)
  }
  onAppointmentUpdating(appointmentInfo) {
    // this.onAppointmentAdding(appointmentInfo.newData, true, appointmentInfo.newData.id);
  }


  GetRole() {
    return this.schedulerSr.AddSkills(this.loginId, this.interviewer);

  }

  CandidateFeedBack() {

    if (this.candidate.Cname == undefined || this.candidate.Cname == "") {
      // console.log("undefined is working")
      this.error = "Candidate Name Required"
    } else if (this.candidate.Cemail == undefined || this.candidate.Cemail == "") {
      // console.log("undefined is working")
      this.error = "Candidate Email Required"
    } else if (this.candidate.status == undefined || this.candidate.status == "") {
      // console.log("undefined is working")
      this.error = "Candidate Status Required"
    } else if (this.candidate.Ccomments == undefined || this.candidate.Ccomments == "") {
      // console.log("undefined is working")
      this.error = "Candidate Comment Required"
    } else {
      this.schedulerSr.Candid_status(this.candidate);
      
    }
    
  }
}
