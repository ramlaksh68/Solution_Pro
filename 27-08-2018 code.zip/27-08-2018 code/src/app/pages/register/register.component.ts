import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { AuthService } from "../../services/auth.service";
import { SnotifyService, SnotifyPosition, SnotifyToastConfig } from 'ng-snotify';
import { Router } from '@angular/router';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
    style = 'dark';
  RegisterForm;
  error: string;
  position: SnotifyPosition = SnotifyPosition.rightBottom;


  constructor(fb: FormBuilder, public auth: AuthService, private snotifyService: SnotifyService, public router:Router) {
    this.RegisterForm = fb.group({
      'name': ['', Validators.required],
      'email': ['', Validators.required],
      'phone': ['', Validators.required],
      'role': ['', Validators.required]
    });
  }

  ngOnInit() {
  }

//  getConfig(): SnotifyToastConfig {
//     this.snotifyService.setDefaults({
//       global: {
//         newOnTop: true,
//         maxAtPosition: 6,
//         maxOnScreen: 8
//       }
//     });
//     return {
//       bodyMaxLength: 17,
//       titleMaxLength: 20,
//       backdrop: -1,
//       position: this.position,
//       timeout: 2000,
//       showProgressBar: false,
//       closeOnClick: false,
//       pauseOnHover: false
//     };
//   }


  Register(data) {
    // if (data.fullname == "" && data.email == "" && data.phone == "" && data.role == "") {
    //   let error = "Enter valid data";
    //       this.snotifyService.success('',error, {
    //   bodyMaxLength: 17,
    //   titleMaxLength: 20,
    //   backdrop: -1,
    //   position: this.position,
    //   timeout: 2000,
    //   showProgressBar: false,
    //   closeOnClick: false,
    //   pauseOnHover: false
    // });
    // } else {
    //   this.error = null;
    // }

    // if (data.fullname == "") {
    //   console.log("enter valid name")
    // } else if (data.email == "") {
    //   console.log("enter valid email")
    // } else if (data.phone == "") {
    //   console.log("enter valid phone")
    // } if (data.role == "") {
    //   console.log("enter valid role is required")
    // } else {
    //   console.log("enter valid data")
    // }
    

    if(data.role == 'I'){
     var intobj= { interviewerId:data.name,
	interviewerName:data.name,
	interviewerEmail:data.email,
 interviewerMob:data.phone,
	 interviewerRole:data.role}
        this.auth.InterviewerRegister(intobj);
          this.router.navigate(['/login'])
    }else{
       var hrobj= { hrId:data.name,
	hrName:data.name,
	hrEmail:data.email,
 hrMobile:data.phone,
	 hrRole:data.role}
        this.auth.HrRegister(hrobj);
          this.router.navigate(['/login'])
    }
   
  }

}
