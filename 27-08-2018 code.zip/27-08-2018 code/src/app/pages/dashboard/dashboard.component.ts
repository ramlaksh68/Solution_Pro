import { Component, OnInit, Input } from '@angular/core';
// import { HeaderComponent } from '../../header/header.component';
import { Router } from '@angular/router';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  hrview: boolean = true;
  constructor(public router: Router) {
    if (this.router.url == "/dashboard/hr") {
      this.hrview = false;
    }

  }

  ngOnInit() {

    //   YUI().use('aui-scheduler', function (Y) {
    //           var items = [{
    //               content: 'Wake Early'
    //           }, {
    //               content: 'Exercise'
    //           },];
    //           var instanceColor = "#0000ff";
    //           var instance = "";
    //           var user = "suchitra";
    //           var schedulerViews = [
    //               new Y.SchedulerWeekView(),
    //               new Y.SchedulerDayView(),
    //               new Y.SchedulerMonthView(),
    //               new Y.SchedulerAgendaView()
    //           ];
    //           var eventRecorder = new Y.SchedulerEventRecorder({
    //               on: {
    //                   save: function (event) {
    //                       // $.ajax({
    //                       //     type: 'POST',
    //                       //     url: 'http://localhost:8080/candidate/schedule/confim',
    //                       //     data: { 'do': 'availability-delete', 'booking_status': data.booking_status, 'shift_type': data.shift_type, 'date_start': ds.getFullYear() + '-' + (ds.getMonth() + 1) + '-' + ds.getDate(), 'date_end': de.getFullYear() + '/' + (de.getMonth() + 1) + '/' + de.getDate() },
    //                       //     success: function (data) {
    //                       //         console.log(data); // show response from the php script.
    //                       //     }
    //                       // });
    //                       console.log('Save Event:' + this.isNew() + ' --- ' + this.getTemplateData().content + " Available from " + this.getTemplateData().startDate + " to " + this.getTemplateData().endDate + " accepted on " + this.getTemplateData().date);
    //                   },
    //                   edit: function (event) {

    //                       //this.Do.after.set('color', '#00ff00');
    //                       console.log('Save Event:' + this.isNew() + ' --- ' + this.getTemplateData().content + " Available from " + this.getTemplateData().startDate + " to " + this.getTemplateData().endDate + " accepted on " + this.getTemplateData().date);
    //                   },
    //                   delete: function (event) {
    //                       // Note: The cancel event seems to be buggy and occurs at the wrong times, so I commented it out.
    //                   },
    //                   cancel: function (event) {
    //                       this.hidePopover();
    //                       //alert('Cancel Event');
    //                   }
    //               },
    //               allDay: false,
    //               //disabled: true,
    //               content: user,
    //               //repeated: true,
    //               headerTemplate: 'Please Select the below TimeSlot',
    //               clientId: '2830b9d7cf',

    //               // prototype: {
    //               //     _onClickSchedulerEvent: function (event) {
    //               //         var instance = this;
    //               //         var evt = event.currentTarget.getData('scheduler-event');

    //               //         if (evt) {
    //               //             alert(' Event:' + evt.isNew() + ' --- ' + evt.get('eventId') + ' startdate : ' + evt.get('startDate') + ' enddate : ' + evt.get('endDate'));

    //               //             if (confirm("Please confirm below Time Slot")) {
    //               //                 
    //               //             }
    //               //         }
    //               //     }
    //               // }
    //           });

    //           Y.Do.after(function () {
    //              // var allday = y.one('#scheduler .scheduler-view-table-container');
    //               var titles = Y.one('#scheduler .popover-title');
    //               titles.removeChild(titles._stateProxy.childNodes[0]);
    //               titles.appendChild('<label"><b>Please Select the below Time Slot</b></label>');
    //               //eventRecorder.set('color', instanceColor);
    //           }, eventRecorder, 'showPopover');


    //           new Y.Scheduler({
    //               boundingBox: '#scheduler',
    //               items: items,
    //               views: schedulerViews,
    //               activeView: schedulerViews[0],
    //               eventRecorder: eventRecorder,
    //               firstDayOfWeek: 1,
    //               // activeView: weekView,
    //               // views: [dayView, weekView, monthView, agendaView]
    //           }).render();

    //       });
  }



}
