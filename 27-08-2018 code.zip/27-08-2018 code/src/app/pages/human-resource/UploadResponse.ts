export class UploadResponse {
    docId:String = "";
    status:String = "";

    constructor(response: String, status: String) {}

}