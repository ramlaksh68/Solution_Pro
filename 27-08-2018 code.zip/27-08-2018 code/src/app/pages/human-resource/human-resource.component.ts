import { Component, OnInit, Input, ViewChild, EventEmitter, OnDestroy, HostListener } from '@angular/core';
import { Router } from "@angular/router";
import { HttpClient, HttpResponse, HttpEventType, HttpHeaders } from '@angular/common/http';
import { UploadResponse } from './UploadResponse';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Location } from '@angular/common';
import { Observable } from 'rxjs';
import { OrderPipe } from 'ngx-order-pipe';
import { NgxPaginationModule } from 'ngx-pagination';
import { Http, RequestOptions, Headers } from '@angular/http';
import { isEqual, differenceWith } from 'lodash';
import * as _ from "lodash";
//service 
import { HumanResourceService } from '../../services/HumanResource.service';
import { ChangeDetectorRef } from '@angular/core';
import { HotTableRegisterer } from '@handsontable/angular';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { DxSchedulerComponent } from 'devextreme-angular/ui/scheduler';
import data from 'devextreme/data/custom_store';
import { SchedulerSearvice } from "../../services";
import { Editcandidate } from "../EditCandidates/editcandidate.component";
import { Angular5Csv } from 'angular5-csv/Angular5-csv';
import { AuthService } from '../../services/auth.service';
declare var $:any;

@Component({
  selector: 'app-human-resource',
  templateUrl: './human-resource.component.html',
  styleUrls: ['./human-resource.component.css'],
  providers: [HotTableRegisterer]
})
export class HumanResourceComponent implements OnInit {
  @ViewChild(Editcandidate) child;
  @ViewChild(DxSchedulerComponent) scheduler: DxSchedulerComponent;
  columnSorting: {
    column: 2,
    sortOrder: 'desc', // 'asc' = ascending, 'desc' = descending, 'none' = original order
  }
  scheduledbject : Array<Object>;
  schedulejobid : any;
  term: string;
  search: true;
  ExpandData = [];
  p: number = 1;
  currentPage: number;
  pageSize: number;
  totalItems?: number;
  numberOfPages?: number;
  order: string = 'score';
  searchResume;
  hideData: boolean = true;
  currentUpload: "";
  dropzoneActive: boolean = false;
  error_Message: string = "";
  fileToUpload: any=[];
  progress: { percentage: number } = { percentage: 0 }
  resumeResults: any=[{  
    "address":"No Service",
    "comments":"No Comments",
    "docId":"9472642d1485488db336b7adba877a5c",
    "emailId":"adit2310@yahoo.com",
    "fileName":"adityaimmaneni[9_0].doc",
    "interestingFlag":"No",
    "name":"Aditya Immaneni",
    "phoneNumber":"9581049265",
    "qualification":"null",
    "relExp":3,
    "score":0,
    "skillBreakup":{  
       "TotalScore":105,
       "bigdata":5,
       "cocoa":61,
       "devops":2,
       "java":32,
       "project_management":12,
       "ui":11
    },
    "status":"Pending",
    "summary":{  
       "CurrentTechnologyScore":45,
       "New_Technology_Score":25,
       "OldTechnologyScore":30
    }
 },{  
  "address":"Chennai",
  "comments":"Good Person",
  "docId":"9472642d14adba877a5c",
  "emailId":"ram2310@yahoo.com",
  "fileName":"adityaimmaneni[9_0].doc",
  "interestingFlag":"No",
  "name":"Ram Murugappan",
  "phoneNumber":"9578049265",
  "qualification":"null",
  "relExp":3,
  "score":0,
  "skillBreakup":{  
     "TotalScore":78,
     "bigdata":5,
     "cocoa":45,
     "devops":2,
     "java":32,
     "project_management":12,
     "ui":11
  },
  "status":"Pending",
  "summary":{  
     "CurrentTechnologyScore":50,
     "New_Technology_Score":10,
     "OldTechnologyScore":40
  }
}];
  showComplete: boolean = false;
  HideUpload: boolean = true;
  resultsval: any;
  EditData :Object;
  EnableAction: boolean = false;
  disableEdit: boolean = true;
  UpDateForm: FormGroup;
  reportProgress = false;
  TempData = [];
  collapseAni: any;
  userReleventScore = [];
  skillBreakKey = [];
  skillBreakValue = [];
  ShowClear: boolean;
  searchItem: any;
  JDsearchItem: any;
  showJD: boolean = false;
  Updated = {
    "name": "",
    "emailid": "",
    "address": "",
    "phoneNum": "",
    "edu": "",
    "univ": "",
    "totExp": "",
    "relvExp": "",
    "score": "",
    "key": "",
    "status": "",
    "summary": ""
  }
  Updatedname: string;
  UpdatedemailId: any;
  UpdatedphoneNumber: string;
  uploadFile: any;
  updateData_name: any = null;
  updateData_email: any = null;
  updatedData_phoneno: any = null;
  uploadMessage: any;
  StatusData = ["Shortlist", "cancelled", "Management", "Hr", "Selected", "Not Selected", "On Hold", "Offered", "Accepeted", "Non Accepeted"];
  public TempdocId: string[];
  public selectedCandidEmail = []
  selectedAllResume;
  widgets = [
    {
      "id": 1,
      "name": "Recent Profiles",
      "count": 0,
      "class": "voilet",
      "img": "./assets/img/doc.svg"
    },
    {
      "id": 2,
      "name": "Total Profiles",
      "count": 0,
      "class": "blue",
      "img": "./assets/img/doc.svg"
    },
    {
      "id": 3,
      "name": "Top Ranked",
      "count": 0,
      "class": "voilet",
      "img": "./assets/img/quality.svg"
    },
    {
      "id": 4,
      "name": "Resource Requirments",
      "count": 0,
      "class": "blue",
      "img": "./assets/img/star.svg"
    },
    {
      "id": 5,
      "name": "Interesting Profiles",
      "count": 0,
      "class": "green",
      "img": "./assets/img/file.svg"
    }
  ]
  reverse: boolean = false;
  sortedCollection: any[];
  HrServiceCount;
  dataSource = [];
  public dataFormat: any;
  currentUser = localStorage.getItem('username');
  token: any = localStorage.getItem('Token');
  public loginId = localStorage.getItem('username');
  public dummyData;
  schedulerList:any = [];
  schedulerListLen = 0;
  hideme: boolean = true;
  SchedulerListForm: FormGroup;

  @Input('sortable-column')
  columnName: string;

  @Input('sort-direction')
  sortDirection: string = '';

  @HostListener('click')
  sort() {
    this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
  }

  constructor(private router: Router,
    public auth: AuthService,
    public schedulerSr: SchedulerSearvice,
    private location: Location,
    public HrService: HumanResourceService,
    public orderPipe: OrderPipe,
    private fb: FormBuilder,
    public _http: HttpClient,
    private cd: ChangeDetectorRef,
    private _registerer: HotTableRegisterer) {
    //Listout candidates
    this.canditList();

    this.UpDateForm = fb.group({
      'name': [null, Validators.required],
      'email': [null, Validators.required]
    })
  }

  ngOnInit() {
    this.PageStart();

  }

  PageStart() {

    this.setOrder("score");

  }

  // TO LISTOUT CANDIDATE LIST
  canditList() {
    let tempArray = [];
    let splitData = [];
    let splitArr = [];
    this.HrService.ShowRecentFiles()
      .subscribe((data) => {
        if (data) {
          this.resumeResults = '';
          this.resumeResults = data;
          // sort By Score 
          console.log(this.resumeResults)
          this.sortedCollection = this.orderPipe.transform(this.resumeResults, 'score');
        }
      });

    this.HrService.gettotalProfilesCountUrl().subscribe((data) => {
      this.HrServiceCount = data;
      this.widgets[1].count = parseInt(this.HrServiceCount);
    });
    this.HrService.getRetrieveTopProfilesCountUrl().subscribe((data) => {
      this.HrServiceCount = data;
      this.widgets[2].count = parseInt(this.HrServiceCount);
    });
    this.HrService.getResourceReq().subscribe((data) => {
      this.HrServiceCount = data;
      this.widgets[3].count = parseInt(this.HrServiceCount);
    });
    this.HrService.getInterestingProfilesCount().subscribe((data) => {
      this.HrServiceCount = data;
      this.widgets[4].count = parseInt(this.HrServiceCount);
    });
  }


  uploadResume() {
    this.router.navigate(['/dashboard/hr/uploadResume']);
  }

  onFileSelected(event) {
    console.log(event)
    this.progress.percentage = 0;
    this.fileToUpload = event.target.files;
  }


  uploadFileToActivity() {
    if(!this.fileToUpload||this.fileToUpload.length == 0)
      {
        this.error_Message = "Please Choose Your Resume"
        return ;
      }
      this.error_Message="";
    this.reportProgress = true;
    this.HrService.pushFileToStorage(this.fileToUpload).subscribe(
      (uploadResponse: any) => {
        if (uploadResponse.status) {
          this.showComplete = true;
          this.HideUpload = false;
          this.reportProgress = false;
          this.uploadMessage = uploadResponse.status;
        }
      },
      error => { });
  }




  //Close Popup Clear FIles in popup data 
  clear() {
    delete this.fileToUpload;
    this.error_Message = "";
    this.showComplete = false;
    this.HideUpload = true;
  }

  getFile() {
    delete this.fileToUpload;
  }

  handleDrop(file: FileList) {
    this.onFileSelected(file);
  }




  //  Sorting table

  setOrder(value: string) {

    this.reverse = !this.reverse;

    this.order = value;
  }

  EditProfile($id) {
    console.log("id:", $id)

    this.resumeResults.forEach(EditEle => {
      if ($id == EditEle.docId) {
       this.EditData=EditEle
      }
    });
    // this.EditRowId = "";
    // this.EnableAction = false;
    // this.EditRowId = undefined;
    // let headers = new HttpHeaders({ "Content-Type": "application/json" });
    // const url = "http://localhost:8000/api/updateDetails";
    // return this._http.put(url, this.TempData, { headers })
    //   .map(success => success).subscribe(data => { console.log("success") });
  }

  getChanges(orginalCollection: any, changedCollection: any): any {
    return differenceWith(changedCollection, orginalCollection, isEqual);
  }

  expandBox($e) {

    this.resumeResults.forEach(data => {
      if (data.docId == $e) {
        this.ExpandData.push(data);
      }
    });
  }

  private handleError(error: Response | any) {
    console.error(error.message || error);
    return Observable.throw(error.status);
  }

  //Single File Download 
  downloadProfile() {
    // let download_data;

    console.log(this.TempdocId)
    // this.HrService.DownloadCv(docId)
    //   .subscribe(params => {
    //     download_data = params['url'];
    //     console.log(download_data)
    //     location.assign(download_data);
    //   });
  }

  //Select All Profile To Download 
  selectAll() {
    for (var i = 0; i < this.resumeResults.length; i++) {
      this.resumeResults[i].docId = this.selectedAllResume;
    }
  }
  checkIfAllSelected() {
    this.selectedAllResume = this.resumeResults.every(function (item: any) {
      console.log(item)
    })
  }

  //Download Single Profile
  DownloadSingleProfile($event) {
    console.log($event)
    let download_data;
    let ids = ["6d78afc4b3bb411dab721b9646e776b6", "7a856a98807a415796dd898f7a4b6833", "6d78afc4b3bb411dab721b9646e776b6"];
    for (let i = 0; i < ids.length; i++) {
      this.HrService.DownloadCv(ids[i])
        .subscribe(params => {
          download_data = params['url'];
          location.assign(download_data);
        });
    }
  }

  widgetBasedCandit(e) {
    console.log(e)
    if (e == "Interesting Profiles") {
      delete this.resumeResults;
      this.HrService.ShowRecentFiles()
        .subscribe((data) => {
          let temp;
          let arr = [];
          temp = data;
          for (let i = 0; i < temp.length; i++) {

            if (temp[i].interestingFlag == "Yes") {
              arr.push(temp[i])

            }
          }
          this.resumeResults = arr;
        });
    }

    else {
      this.HrService.ShowRecentFiles()
        .subscribe((data) => { this.resumeResults = data; });
    }
  }

  //CollapseFun
  collapsee(i) {
    this.collapseAni = i;
  }

  DefaultFun(params) {

    var defaultSortModel = [
      {
        colId: "score",
        sort: "desc"
      }
    ];
    params.api.setSortModel(defaultSortModel);
    params.api.sizeColumnsToFit();
    setTimeout(function () {
      var rowCount = 0;
      params.api.forEachNode(function (node) {
        node.setExpanded(rowCount++ === 1);
      });
    }, 500);
  }


  //Send Mail
  sendEmail() {
    this.HrService.mail();
  }

  // Export CSV
  export() {
    let header = { headers: ['', '', 'Name', 'Mobile.No', 'Email', '', '', 'Status', '', '', '', 'Skills', 'University', 'Education', 'Summary', 'city'] }
    new Angular5Csv(this.resumeResults, 'Report', header)
  }

  // Header Functions


  // Scheduler List 
  // schedulerPanel(){
  //   return this.HrService.getSchedulePanleData().subscribe(data => {return data});
  // }

  // Nlp Search
  SearchTyping($e) {

    if ($e != "") {
      this.ShowClear = true;
    } else if ($e == "") {
      this.ShowClear = false;
    }
  }

  clearSearchArea() {
    delete this.searchItem;
    delete this.JDsearchItem;
    this.ShowClear = false;
  }



  ShowJdTextAreaa() {
    this.showJD = !this.showJD;
  }
  Nplsearch(e) {
    this.showJD = true;
    this.HrService.getSchedulePanleData().subscribe(data => { 
     this.schedulerList=data; 
      this.schedulerListLen = this.schedulerList.length;
       console.log(this.schedulerList)
       });
    // this.schedulerPanel();
    this.HrService.searchApi(data).subscribe((res) => {
      let resultdata = JSON.parse(res._body);
      this.hideData = false;
      this.resumeResults = "";
      this.resumeResults = resultdata;
    });
    this.ShowJdTextAreaa();
    this.ShowClear = false;
    this.clearSearchArea();
  }

  JDsearch(e) {
    this.HrService.JDsearchApi(e).subscribe((res) => {
      let resultdata = JSON.parse(res._body);
      this.hideData = false;
      this.resumeResults = "";
      this.resumeResults = resultdata;
    });
    this.ShowJdTextAreaa();
    this.ShowClear = false;
    this.clearSearchArea();
  }

  logout() {
    this.auth.logout();
  }

  // selected Candidate
  selectcandidate($email,$docId){
    let SelectedJson = {
      "emailId":$email,
      "docId":$docId
    }
    this.selectedCandidEmail.push(SelectedJson);
    console.log(this.selectedCandidEmail);
  }

  
markScheduler(item){
  item.ismark=true; 
}

getSchedularDetail(){
  if($("#scheduleFrom")[0].reportValidity())
  this.scheduledbject=this.schedulerList.filter(data=>data.ismark).map((emp)=>{
    return {"interviewerId" : emp.interviewerId,
    "candidateId" : "12345",
    "role": emp.interviewerRole,
    "jobId" :this.schedulejobid,
    "slotId" : "1234",
    "sTime" : "Aug 21 2018 08:00:00",
    "eTime" : "Aug 21 2018 11:00:00",
    "status" : ""};
  });
  console.log("Scheduled Object : ",this.scheduledbject);
  this.HrService.AllocateInterviewer(this.scheduledbject[0]);
}

}
