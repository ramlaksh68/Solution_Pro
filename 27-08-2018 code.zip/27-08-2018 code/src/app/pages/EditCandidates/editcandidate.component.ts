import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { ProfileService } from '../../services/profile.service';
import { UtilityService } from '../../services/utility.service';

@Component({
    selector: 'app-editform',
    templateUrl: './editcandidate.component.html',
    styleUrls: ['./editcandidate.component.css']
})

export class Editcandidate implements OnInit {
    @Output() isedit_mode= new EventEmitter();
    @Input("GetEditData") candidate_data;
    private candidatestatusList:Array<Object>;
    private skillScoreList:Array<Object>;
        //   Chart View Data Set
    public pieChartLabels:string[];
    public pieChartData:number[];
    public pieChartType:string = 'pie';


    constructor(private profileService:ProfileService,private utilityService:UtilityService) {
      
    }

    ngOnInit() {
        console.log("candidate_data",this.candidate_data);
        var data=this.candidate_data.skillBreakup;
        this.skillScoreList=Object.keys(data).map((skill)=>{
            var score=data[skill];var css=score>80?"success":score>65?"primary":score>40?"info":score>25?"warning":"danger";
            return {skill,score,css};
        });
        this.pieChartLabels=Object.keys(this.candidate_data.summary);
        this.pieChartData=Object.values(this.candidate_data.summary);
        this.candidatestatusList=this.utilityService.getCandidateStatusList();
    }

  updateCandidateProfile(){
      this.profileService.updateCandidateProfiles(this.candidate_data).subscribe((res)=>{
          if(res)console.log("updated successfully => ",this.candidate_data);
      })
     this.goBackCandidateProfile();
  }
  goBackCandidateProfile(){
    this.isedit_mode.emit(null);
  }




// events
public chartClicked(e:any):void {
  console.log(e);
}

public chartHovered(e:any):void {
  console.log(e);
}



}