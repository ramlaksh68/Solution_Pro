import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';

//routing
import { AppRoutingModule, routingComponents } from './app.routing';

//directives
import { FileDropDirective } from './directives/file-drop.directive';

// services
// import { AuthService } from './services/auth.service';
// import { SearchService } from './services/search.service';
import { CountService } from './services/totalCount.service';
import { CalenderapiService } from './services/calenderapi.service';
import { UserDataService } from './services/userData.service';
import { UploadFileService } from './services/upload-file.service'
// import { HumanResourceService } from "../app/services/HumanResource.service";

import { AuthService, SchedulerSearvice, HumanResourceService, SearchService } from "./services";


//guards
// import { AuthGuard } from './guards/auth.guard';
import { LoginGuard } from './guards/login.guard';

//library
import { OrderModule } from 'ngx-order-pipe';
import { NgxPaginationModule } from 'ngx-pagination';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { Routes, RouterModule } from '@angular/router';
import { DxCheckBoxModule } from 'devextreme-angular/ui/check-box';
import { DxSchedulerModule } from 'devextreme-angular/ui/scheduler';
import { DxDataGridModule } from 'devextreme-angular/ui/data-grid';
import { HttpClientModule } from '@angular/common/http';
import { Http, Headers, Response } from '@angular/http';
import { HttpModule } from '@angular/http';
import { DropdownModule } from 'angular-custom-dropdown';
import { SnotifyModule, SnotifyService, ToastDefaults } from 'ng-snotify';
import { DataTableModule } from 'angular5-data-table';

//Datatable
import { AgGridModule } from 'ag-grid-angular';
import { ProfileService } from './services/profile.service';
import { UtilityService } from './services/utility.service';
import { ChartsModule } from 'ng2-charts';


@NgModule({
  declarations: [
    AppComponent,
    routingComponents,
    FileDropDirective
  ],
  imports: [
    SnotifyModule,
    DropdownModule,
    BrowserModule,
    HttpClientModule,
    HttpModule,
    FormsModule,
    BsDropdownModule.forRoot(),
    DxSchedulerModule,
    DxDataGridModule,
    DxCheckBoxModule,
    AppRoutingModule,
    ReactiveFormsModule,
    Ng2SearchPipeModule,
    OrderModule,
    NgxPaginationModule,
    AgGridModule.withComponents([]),
    DataTableModule.forRoot(),
    ChartsModule
  ],
  providers: [CalenderapiService,
    HumanResourceService,
    AuthService,
    ProfileService,
    UtilityService,
    UserDataService,
    UploadFileService,
    CountService,
    SearchService,
    SchedulerSearvice,
    LoginGuard,
    { provide: 'SnotifyToastConfig', useValue: ToastDefaults },
    SnotifyService],
  bootstrap: [AppComponent]
})
export class AppModule { }
