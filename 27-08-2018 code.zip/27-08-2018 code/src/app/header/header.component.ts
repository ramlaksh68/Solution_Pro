import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { AuthService } from '../services/auth.service';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { HumanResourceService } from '../services/HumanResource.service';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  routePath;
  currentUser;
  results: any = "";
  ShowClear: boolean;
  searchItem: any;
  JDsearchItem: any;
  showJD: boolean = false;
  constructor(private route: ActivatedRoute, 
    router: Router,
     public auth: AuthService, 
    public search: HumanResourceService) {
    router.events.subscribe();
    this.routePath = router.url.split("/")[2];
  }

  ngOnInit() {
    this.currentUser = localStorage.getItem('username');
  }

  logout() {
    this.auth.logout();
  }

  Nplsearch(e) {
this.showJD =true;
    this.search.emitSearch(e);
    this.ShowJdTextAreaa();
    this.ShowClear = false;
  }

  JDsearch(e) {
   this.search.emitJDSearch(e);
    this.ShowJdTextAreaa();
    this.ShowClear = false;
  }

  SearchTyping($e) {

    if ($e != "") {
      this.ShowClear = true;
    } else if ($e == "") {
      this.ShowClear = false;
    }
  }

  clearSearchArea() {
    delete this.searchItem;
    delete this.JDsearchItem;
    this.ShowClear = false;
  }

  ShowJdTextAreaa() {
    this.showJD = !this.showJD;
  }

   
}
