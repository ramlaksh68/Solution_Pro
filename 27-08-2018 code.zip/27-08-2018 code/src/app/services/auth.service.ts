import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { Token } from '../classes/token';

@Injectable()
export class AuthService {
  private isUserLoggedIn;
  tokenParam: Token;
  token: string;
  json: any;

  public username;
  private loginUrl = "http://18.218.130.252:8080/recruitweb/api/v1/token/generate"
  constructor(public router: Router, private http: Http) {
    this.isUserLoggedIn = false;
  }

  HrRegister(data){
    this.http.post("http://localhost:8500/recruitweb/api/v1/hr/register",data).subscribe(data)
    
  }

  InterviewerRegister(data){
    console.log(data)
    this.http.post("http://10.1.2.94:8500/recruitweb/api/v1/interviewer/slot/register",data).subscribe(data)
    
  }

  SetLoggedIn(name: string, password: string): Observable<Token> {
    let header = new Headers({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer '
    });
    var data = { "loginId": name, "password": password };
    return this.http.post(this.loginUrl, data, { headers: header })
      .map(res => this.json = res.json())
      .catch(this.ErrorLogin)
  }

  ErrorLogin(error: Response | any): Observable<any> {
    return Observable.throw(error);
  }



  logout(): void {
    this.isUserLoggedIn = false;
    this.router.navigate(['/login']);
    localStorage.clear();
  }
}
