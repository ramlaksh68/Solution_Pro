import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

@Injectable()
export class CountService {

  private totalProfilesCountUrl="http://10.1.2.96:8000/api/getTotalProfilesCount";
  private retrieveTopProfilesCountUrl="http://10.1.2.96:8000/api/retrieveTopProfilesCount";
  private resourceReqUrl="http://10.1.2.96:8000/api/resourceReq";
  private getInterestingProfilesCountUrl="http://10.1.2.96:8000/api/getInterestingProfilesCount";

  constructor(public Http:HttpClient) { }

  
  gettotalProfilesCountUrl()
  {
       return this.Http.get(this.totalProfilesCountUrl).map((res) => {
        return res;
      });
    
  }
  
  getRetrieveTopProfilesCountUrl()
  {
 return this.Http.get(this.retrieveTopProfilesCountUrl).map((res) => {
        return res;
      });
  
  }
  
  getResourceReq()
  {
      return this.Http.get(this.resourceReqUrl).map((res) => {
        return res;
      });
   
  }

  getInterestingProfilesCount()
  {
      return this.Http.get(this.getInterestingProfilesCountUrl).map((res) => {
        return res;
      });
   
  }

  


}


