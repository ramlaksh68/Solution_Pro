import { Injectable, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { Observable } from 'rxjs/Observable';
import { Http } from '@angular/http';



@Injectable()
export class UtilityService {
private candidate_status_list:Array<Object>;

    constructor(){
        this.candidate_status_list=[
            { text:"New",value:"New"},
            { text:" In progress ",value:"In progress"},
            { text:"Management Round",value:"Management Round"},
            { text:"Shortlisted",value:"Shortlisted"},
            { text:"Selected",value:"Selected"},
            { text:"Offered",value:"Offered"},
            { text:"Offer accepted",value:"Offer accepted"},
            { text:"Joined",value:"Joined"},
            { text:"Offer declined",value:"Offer declined"},
            { text:"No Response",value:"No Response"},
            { text:"Rejected",value:"Rejected"},
            { text:"Pending",value:"Pending"},
            { text:"RSL",value:"RSL"}
        ]
    }

    getCandidateStatusList(){
        return this.candidate_status_list;
    }

}
