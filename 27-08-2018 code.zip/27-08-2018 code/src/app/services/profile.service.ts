import { HttpClient, HttpResponse, HttpEventType, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
// import { HttpHeaders } from '@angular/common/http';

// const httpOptions = {
//   headers: new HttpHeaders({
//     'Content-Type': 'application/x-www-form-urlencoded',
//     'accept': 'application/json'
//   })
// };


@Injectable()
export class ProfileService {
  private profileUrl = "http://10.1.2.96:8000/api/retrieveAllFileDetails";
  private CANDIDATE_UPDATE_URL = "http://localhost:8000/api/updateDetails";
  constructor(public Http: HttpClient, public _http: Http) { }

  //Recent Candidates List
  ShowRecentFiles() {
    return this.Http.get(this.profileUrl)
      .map((res: Response) => res);
  }

  DownloadCv(id) {

    let headers = new HttpHeaders();
    headers.append("Content-Type", "text/plain")
    return this._http.get("http://10.1.2.96:8000/api/downloadFile/"+id)
      .map(res => {
      return res
      });
  }
  // //Edit Candidates
  // SendUpdateFiles(data): Observable<any> {
  //   console.log(data)
  //   let cpHeaders = { headers: new Headers({ 'Content-Type': 'application/json' })};
  //   // let HeaderOptions = new RequestOptions({ headers: cpHeaders });

  //   return this._http.put("http://192.168.10.109:8000/api/updateDetails", {"resume":a},cpHeaders)
  //    .map(success => success.status)
  //              .catch(this.handleError);
  // }

  //  private handleError (error: Response | any) {
  // console.error(error.message || error);
  // return Observable.throw(error.status);
  //   }



  updateCandidateProfiles(candidate){
    return this.Http.put(this.CANDIDATE_UPDATE_URL,candidate);
  }
}
