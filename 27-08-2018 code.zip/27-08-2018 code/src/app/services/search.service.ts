import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { Observable } from 'rxjs/Observable';
import { Http } from '@angular/http';



@Injectable()
export class SearchService {

  private searchSubject = new Subject<string>();
  $searchSubject = this.searchSubject.asObservable();
  private result;
  constructor(private http: Http) { }


  emitSearch(searchString) {

    this.searchSubject.next(searchString);
    console.log('searchString', searchString);
  }


  searchApi($event): Observable<any> {

    let formdata: FormData = new FormData();
    formdata.append('searchContent',$event);
    console.log(formdata);
    return this.http.post("http://10.1.2.96:8000/api/search", formdata)
      .map((res) => {
        return res;
      });
  
  }

}
