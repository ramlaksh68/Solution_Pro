import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { HttpClient, HttpResponse, HttpEventType, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { Subject } from 'rxjs';
import { UploadResponse } from '../pages/human-resource/UploadResponse'


@Injectable()
export class HumanResourceService {
    configUrl = '../assets/config.json';
    private profileUrl = "http://10.1.2.94:8000/api/retrieveAllFileDetails";
    private searchSubject = new Subject<string>();
    $searchSubject = this.searchSubject.asObservable();
    private JDsearchSubject = new Subject<string>();
    $JDsearchSubject = this.JDsearchSubject.asObservable();
    private result;
    public apiUrls;
    private token: any = localStorage.getItem("Token");
    public httpOptions = {
        headers: new HttpHeaders({
            'Authorization': 'Bearer ' + this.token
        })
    };
    private totalProfilesCountUrl = "http://10.1.2.94:8000/api/getTotalProfilesCount";
    private retrieveTopProfilesCountUrl = "http://10.1.2.94:8000/api/retrieveTopProfilesCount";
    private resourceReqUrl = "http://10.1.2.94:8000/api/resourceReq";
    private getInterestingProfilesCountUrl = "http://10.1.2.94:8000/api/getInterestingProfilesCount";

    constructor(public Http: HttpClient, public _http: Http) {
        this.getConfig();

    }

    // Config Json 
    getConfig() {

        return this.Http.get(this.configUrl).subscribe();

    }


    //Recent Candidates List
    ShowRecentFiles() {
        return this.Http.get(this.profileUrl)
            .map((res: Response) => res);
    }

    //Download Resume
    DownloadCv(id) {
        console.log(id)

        //   console.log(ids.length)
        let headers = new HttpHeaders();
        headers.append("Content-Type", "text/plain")

        // console.log(ids[i])
        return this._http.get("http://10.1.2.94:8000/api/downloadFile/" + id)
            .map(res => {
                return res
            });


    }

    //searchResume
    emitSearch(searchString) {
        this.searchSubject.next(searchString);
    }
    emitJDSearch($search) {
        this.JDsearchSubject.next($search);
    }
    searchApi($event): Observable<any> {
        let formdata: FormData = new FormData();
        formdata.append('searchContent', $event);
        return this._http.post("http://10.1.2.94:8000/api/search", formdata)
            .map((res) => {

                return res;
            });
    }

    JDsearchApi($event): Observable<any> {
        let formdata: FormData = new FormData();
        formdata.append('searchContent', $event);
        return this._http.post("http://10.1.2.94:8000/api/jdBasedSearch", formdata)
            .map((res) => {

                return res;
            });
    }


    //Upload Resume 
    pushFileToStorage(file): Observable<UploadResponse> {
        let formdata: FormData = new FormData();
        for(var i=0;i<file.length;i++)
        formdata.append('file', file[0]);
      console.log(file);
        return this.Http
            .post<UploadResponse>("http://10.1.2.94:8000/api/insertFile", formdata)
            .map(res => {
                console.log(res)
                return res;
            }).catch((err) => {
                console.log("error handler")
                return Observable.throw(err)
            });

    }


    //Total Profile 
    gettotalProfilesCountUrl() {
        // let url = this.apiUrls.HumanResources.TotalProfile;
        // console.log(url)
        return this.Http.get(this.totalProfilesCountUrl).map((res) => {
            return res;
        });
    }


    //Top Rank 
    getRetrieveTopProfilesCountUrl() {
        // let url = this.apiUrls.HumanResources.TotalProfile;
        return this.Http.get(this.retrieveTopProfilesCountUrl).map((res) => {
            return res;
        });
    }


    //Resource Requirments 
    getResourceReq() {
        // let url = this.apiUrls.HumanResources.TotalProfile;
        return this.Http.get(this.resourceReqUrl).map((res) => {
            return res;
        });
    }


    //Intresting Profile 
    getInterestingProfilesCount() {
        // let url = this.apiUrls.HumanResources.TotalProfile;
        return this.Http.get(this.getInterestingProfilesCountUrl).map((res) => {
            return res;
        });
    }

    getSchedulePanleData() {
        return this.Http.get('http://10.1.2.94:8500/recruitweb/api/v1/hr/panelView', this.httpOptions)
            .map(res => { return res });
    }

    mail() {
        let formdata: FormData = new FormData();
        let data = "db52542cbea6490ab618e2ed36dc16c9,8c26b269de12434fa3cb68c2cfe8107f";
        formdata.append('docIds', data);
        return this.Http.post('http://10.1.2.94:8000/api/sendEmails', formdata)
            .subscribe(res => { return res });
    }

    AllocateInterviewer($e){
        let url = "http://localhost:8500/recruitweb/api/v1/hr/update/jobid";
        return this.Http.post(url, $e ,this.httpOptions).subscribe(data => { console.log(data)});
    }

   
}

