import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest, HttpEvent } from '@angular/common/http';
import { Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';

import { UploadResponse } from '../pages/human-resource/UploadResponse'

@Injectable()
export class UploadFileService {

    constructor(private http: HttpClient) { }
    _upload (file: File) {
        let formdata: FormData = new FormData();
        // let headers = new Headers({ 'Content-Type': 'application/json' });
        // let options = new RequestOptions({ headers: headers });
        formdata.append('file', file);

        const req = new HttpRequest('POST', 'http://192.168.10.109:8000/api/insertFile', formdata, {
        reportProgress: true,
        });

        this.http.request(req).subscribe(
            (event: any) => {
            console.log('eveny', event)
            const percentDone = Math.round(100 * event.loaded / event.total);
            console.log(`File is ${percentDone}% uploaded.`);
        })
    }

    pushFileToStorage(file: File): Observable<UploadResponse> {
        let formdata: FormData = new FormData();
        formdata.append('file', file);
        return this.http
            .post<UploadResponse>("http://192.168.10.109:8000/api/insertFile", formdata)
            .map(res => {
                return res;
            }).catch((err) => {
                console.log("error handler")
                return Observable.throw(err)
            });

    }



    private extractData(res: Response) {
        let body = res.json();
        return body || {};
    }
    private handleErrorObservable(error: Response | any) {
        console.error(error.message || error);
        return Observable.throw(error.message || error);
    }
    private handleErrorPromise(error: Response | any) {
        console.error(error.message || error);
        return Promise.reject(error.message || error);
    }

    getResult() {
        let a = 0;
        return this.http.get("http://192.168.10.109:8080/api/insertFile")
    }

}