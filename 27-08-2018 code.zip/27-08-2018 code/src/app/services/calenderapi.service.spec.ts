import { TestBed, inject } from '@angular/core/testing';

import { CalenderapiService } from './calenderapi.service';

describe('CalenderapiService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CalenderapiService]
    });
  });

  it('should be created', inject([CalenderapiService], (service: CalenderapiService) => {
    expect(service).toBeTruthy();
  }));
});
