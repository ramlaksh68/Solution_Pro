import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse, HttpRequest } from '@angular/common/http';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

@Injectable()
export class CalenderapiService {
    private appointments: Appointment[];
    configUrl = './assets/config.json';
    public apiUrls;
    public role: any;
    public token: any;
    httpOptions = {
        headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer'
        })
    };


    constructor(private http: HttpClient) {
        this.appointments = new Array<Appointment>();
        this.getConfig().subscribe(data => { this.apiUrls = data; });
        this.token = localStorage.getItem('Token');
    }

    getConfig() {
        return this.http.get(this.configUrl);
    }

    getAppointments(startDate: Date, endDate: Date): Promise<Appointment[]> {
        return Promise.resolve(this.appointments.filter((appointment) => {
            return appointment.startDate >= startDate && appointment.startDate <= endDate ||
                appointment.endDate >= startDate && appointment.endDate <= endDate;
        })).then(function (arr) { console.log('filtered ' + arr.length); return arr; });
    }
    getResources(): Resource[] {
        return resources;
    }

    addAppointment(appointment: Appointment) {
        this.appointments.push(appointment);
    }
    updateAppointment(updatingAppointment: Appointment, updatedAppointment: Appointment) {
        let index = this.appointments.indexOf(updatingAppointment);
        this.appointments[index] = updatedAppointment;
    }

    removeAppointment(appointment: Appointment) {
        this.appointments = this.appointments.filter(item => item !== appointment);
    }

    getInterviewerSlots() {
        let url = "http://localhost:8500/recruitweb/api/v1/candidate/slot/candidate/getSlot/shwetha/101";
        return this.http.get(url).map(res=> {console.log(res)});
    }

    getslots(loginId: string) {
        let url = this.apiUrls.Candidate.GetSlots + loginId;
        return this.http.get(url, this.httpOptions);
    }

    bookSlotCandidate(EventId: number) {
        let url = this.apiUrls.Candidate.BookSlot + EventId;
        return this.http.get(url, this.httpOptions);
    }

    cancelBookedSlotCandidate(EventId: number) {
        let url = this.apiUrls.Candidate.CancelBookedSlot + EventId;
        return this.http.delete(url, this.httpOptions);
    }

    login(name: string, password: string) {
        return this.http.post<{ "loginId": string, "password": string }>(this.apiUrls.Common.Login, { "loginId": name, "password": password }, this.httpOptions)
            .catch(this.handleError);
    }

    addInterviewerAppointment(startTime: string, endTime: string, isUpdate: boolean, id: number) {
        if (isUpdate) {
            return this.http.post<{ "id": number, "startTime": string, "endTime": string }>(this.apiUrls.Interviewer.Update, { "id": id, "startTime": startTime, "endTime": endTime }, this.httpOptions)
                .catch(this.handleError);
        } else {
            return this.http.post<{ "startTime": string, "endTime": string }>(this.apiUrls.Interviewer.Schedule, { "startTime": startTime, "endTime": endTime }, this.httpOptions)
                .catch(this.handleError);
        }
    }

    deleteInterviewSlot(id: number) {
        let url = this.apiUrls.Interviewer.Delete + id;
        return this.http.delete(url, this.httpOptions);
    }

    postFile(fileToUpload: File) {
        const endpoint = 'http://192.168.10.114:8080/api/insertFile';
        const formData: FormData = new FormData();
        formData.append('fileKey', fileToUpload, fileToUpload.name);
        return this.http
            .post(endpoint, formData)
            .map(() => { return true; })
            .catch((e) => this.handleError(e));
    }

    getFile() {
        return this.http.get("localhost:8080/api/retrieveFileDetails/5aec284f7a21a4afaf3c4d35");
    }

    private handleError(error: HttpErrorResponse) {
        if (error.error instanceof ErrorEvent) {
            // A client-side or network error occurred. Handle it accordingly.
            console.error('An error occurred:', error.error.message);
        } else {
            // The backend returned an unsuccessful response code.
            // The response body may contain clues as to what went wrong,
            console.error(
                `Backend returned code ${error.status}, ` +
                `body was: ${error.error}`);
        }
        // return an ErrorObservable with a user-facing error message
        return new ErrorObservable(
            'Something bad happened; please try again later.');
    };


    //New Changes
    createAuthorizationHeader(headers: Headers) {
        headers.append('Authorization', 'Bearer '+this.token);
    }


    AddInterviewerSchedule(loginId, Slot) {
        // console.log(Slot)
        // console.log("startDate:"+Slot.startDate+"endTime:"+Slot.endDate)
        let slots = "startDate:"+ Slot.startDate + "endTime:"+ Slot.endDate
        // let url = "http://localhost:8080/recruitweb/api/v1/interviewer/slot/interviewer/selectedslot/"+loginId+"/"+slots;
        let url = "http://localhost:8080/recruitweb/api/v1/interviewer/slot/interviewer/selectedslot/shwetha/startDateFri Jul 06 2018 08:00:00 GMT+0530 (India Standard Time)endTimeFri Jul 06 2018 18:00:00 GMT+0530 (India Standard Time)"

        let headers = new Headers();
        this.createAuthorizationHeader(headers);
        console.log(url, {headers: headers})
        return this.http.post(url,{ headers: headers })
            .map(data => console.log(data));
    }


}

export class Appointment {
    id: number;
    text: string;
    description?: string;
    color?: string;
    startDate: Date;
    endDate: Date;
    recurrenceRule?: string;
}

export class Resource {
    text: string;
    id: number;
    color: string;
}

export class Slot {
    id: number;
    startTime: string;
    endTime: string;
    userId: number;
    status: string;
}

let resources: Resource[] = [
    {
        text: 'Samantha Bright',
        id: 1,
        color: '#cb6bb2'
    }, {
        text: 'John Heart',
        id: 2,
        color: '#56ca85'
    }, {
        text: 'Todd Hoffman',
        id: 3,
        color: '#1e90ff'
    }, {
        text: 'Sandra Johnson',
        id: 4,
        color: '#ff9747'
    }
];

let x: Appointment[] = [
    {
        id: 1,
        text: "Website Re-Design Plan",
        startDate: new Date(2017, 4, 22, 9, 30),
        endDate: new Date(2017, 4, 22, 11, 30),
        color: "#cb6bb2"
    }, {
        id: 2,
        text: "Book Flights to San Fran for Sales Trip",
        startDate: new Date(2017, 4, 22, 12, 0),
        endDate: new Date(2017, 4, 22, 13, 0),
        color: "#cb6bb2"

    }
];


