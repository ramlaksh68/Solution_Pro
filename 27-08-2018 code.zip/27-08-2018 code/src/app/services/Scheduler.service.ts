import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, } from '@angular/common/http';
import { Http } from '@angular/http';
import "rxjs";
import { map } from 'rxjs/operators';


@Injectable()
export class SchedulerSearvice {
    // private token: any = localStorage.getItem('Token');
    private token: any = localStorage.getItem("Token");
    public httpOptions = {
        headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + this.token
        })
    };
    public config: any = "assets/config.json";
    apiUrls: any;
    datas: any;
    constructor(public Http: HttpClient, public _http: Http) {
        this.Http.get(this.config)
            .subscribe(data => { 
                this.apiUrls = data ;
                  console.log(this.apiUrls)
            });
      
    }

    createAuthorizationHeader(headers: Headers) {
        headers.append('Authorization', 'Bearer ' + this.token);
    }


    //Interviewer Service
    // ======================================================================================================================================================================================
    // Interviewer Create Slot
    createInterviewSlot($e, id) {
        let url = "http://localhost:8500/recruitweb/api/v1/interviewer/slot/selectedslot/" + id;
        return this.Http.post(url, $e, this.httpOptions).subscribe((data) => { data })
    }

    // Interviewer Get Slot
    ViewInterviewSlots(id) {
        let url = "http://localhost:8500/recruitweb/api/v1/interviewer/slot/getScheduledSlot/" + id + "/1234";
        return this.Http.get(url, this.httpOptions)
            .map((res) => { return res })

    }

    // Interviewer Cancel Slot
    CancelInterviewSlot(id) {
        let url = "http://localhost:8500/recruitweb/api/v1/interviewer/slot/cancelslot/" + id;
        return this.Http.delete(url, this.httpOptions)
            .subscribe(res => { return res })
    }

    // Interviewer Update Slot
    UpdateInterviewSlot($e, id) {

        let url = "http://localhost:8500/recruitweb/api/v1/candidate/slot/candidate/selectedslot/" + id + 121;
        return this.Http.post(url, this.httpOptions).subscribe((data) => { console.log(data) })
    }

    // Add Skills 
    AddSkills(id, $e) {
        let url = "http://localhost:8500/recruitweb/api/v1/interviewer/slot/add/skills/" + id;
        return this.Http.post(url, $e, this.httpOptions).subscribe((data) => { console.log(data) });
    }

    // Add status & comments
    Candid_status(ViewStatus){
        console.log(ViewStatus)
    }

    // =======================================================================================================================================================================================================


    //candidate Service
    // ===================================================================================================================================================================================================
    // Candidate Create Slot
    createCanditSlot($e, id) {

        let url = "http://localhost:8500/recruitweb/api/v1/candidate/slot/candidate/selectedslot/" + id;
        return this.Http.post(url, $e, this.httpOptions)
    }

    // Candidate Get Slot
    ViewCanditSlots(id) {
        let jobId = 12345;
        let url = "http://localhost:8500/recruitweb/api/v1/candidate/slot/getSlot/"+id+"/"+jobId
        return this.Http.get(url, this.httpOptions)
            .map((res) => {  return res })

    }

    // Candidate Cancel Slot
    CancelCanditSlot(data, id) {
        let url = "http://localhost:8500/recruitweb/api/v1/candidate/slot/cancelslot/" + id;
        return this.Http.post(url, data, this.httpOptions).subscribe((res) => { return res })

    }
    // Candidate Cancel Slot
    UpdateCanditSlot($e, id) {
        console.log()
        let url = "http://localhost:8500/recruitweb/api/v1/candidate/slot/selectedslot/" + id;
        return this.Http.post(url, { "sTime": $e }, this.httpOptions).subscribe((data) => { console.log(data) })
    }

    // scheduledSlot
    scheduledslot(id) {
        // http://localhost:8500/recruitweb/api/v1/candidate/slot/getScheduledSlot
        let url = "http://localhost:8500/recruitweb/api/v1/candidate/slot/getScheduledSlot/" + id + "/12345";
        return this.Http.get(url, this.httpOptions).map(data=>{console.log(data)})
    }

}