import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class UserDataService {

  private userObj=new BehaviorSubject<Object>({
    Name:"",
    Password:"",
    Role:""
  });
  currentUser = this.userObj.asObservable();

  constructor() { }

  updateuser(user: Object) {
    this.userObj.next(user);
  }

}