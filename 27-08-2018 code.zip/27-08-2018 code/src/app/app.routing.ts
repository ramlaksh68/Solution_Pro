import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
// import { AuthGuard } from './guards/auth.guard';
import { LoginGuard } from './guards/login.guard';
// Components
import { LoginComponent } from './pages/login/login.component';
import { RegisterComponent } from './pages/register/register.component';
import { FortgotpasswordComponent } from './pages/fortgotpassword/fortgotpassword.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { SchedulerComponent } from './pages/scheduler/scheduler.component';
import { HeaderComponent } from './header/header.component';
import { CandidateComponent } from './pages/candidate/candidate.component';
import { HumanResourceComponent } from './pages/human-resource/human-resource.component';
import { UploadResumeComponent } from './pages/upload-resume/upload-resume.component';
import { NotFoundComponent } from './pages/404/notfound.component';
import { Editcandidate } from "./pages/EditCandidates/editcandidate.component";
const routes: Routes = [


    {
        path: '404',
        component: NotFoundComponent
    },

    {
        path: 'login',
        component: LoginComponent
    },
    {
        path: '',
        redirectTo: '/login',
        pathMatch: 'full'
    },
    {
        path: 'register',
        component: RegisterComponent
    },
    {
        path: 'fortgotPassword',
        component: FortgotpasswordComponent
    },
    {
        path: 'dashboard',
        component: DashboardComponent,


        children: [{
            path: 'interviewer',
            component: SchedulerComponent,
            canActivate: [LoginGuard],
            data: { requiresLogin: true },
        }, {
            path: 'candidate',
            component: CandidateComponent,
            canActivate: [LoginGuard],
            data: { requiresLogin: true }
        }, {
            path: 'hr',
            component: HumanResourceComponent,
            canActivate: [LoginGuard],
            data: { requiresLogin: true },
            children: [
                {
                    path: 'uploadResume',
                    component: UploadResumeComponent
                }
            ]
        }]
    },
    {
        path: '**',
        redirectTo: ''
    }
];

@NgModule({
    imports: [RouterModule.forRoot(routes, { useHash: false })],
    exports: [RouterModule],
})
export class AppRoutingModule { }

export const routingComponents = [
    LoginComponent,
    RegisterComponent,
    FortgotpasswordComponent,
    DashboardComponent,
    SchedulerComponent,
    HeaderComponent,
    CandidateComponent,
    HumanResourceComponent,
    UploadResumeComponent,
    NotFoundComponent,
    Editcandidate
]