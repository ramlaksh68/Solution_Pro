export class Token {
    "token": String;
    "role": String;
}
